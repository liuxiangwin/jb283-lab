@io.vertx.codegen.annotations.ModuleGen(
		groupPackage="com.redhat.training.msa.ciao.service",
	name="ciao-service")
package com.redhat.training.msa.ciao.service;