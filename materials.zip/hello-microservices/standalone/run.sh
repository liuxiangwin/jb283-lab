java -jar target/hello-swarm.jar -Dswarm.management.http.disable=true
