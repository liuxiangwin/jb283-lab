mvn clean package -DskipTests
java -jar target/aloha-swarm.jar -Dswarm.http.port=7070 -Dswarm.management.http.disable=true
