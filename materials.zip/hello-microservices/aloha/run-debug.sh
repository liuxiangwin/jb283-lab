mvn wildfly-swarm:run -Dswarm.debug.port=8001 -Dswarm.http.port=7070 -Dswarm.management.http.disable=true
