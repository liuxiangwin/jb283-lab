mvn wildfly-swarm:run -Dswarm.debug.port=8000 -Dswarm.management.http.disable=true
