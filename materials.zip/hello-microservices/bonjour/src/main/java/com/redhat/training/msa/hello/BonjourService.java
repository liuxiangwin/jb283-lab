package com.redhat.training.msa.hello;

public interface BonjourService {
   public String bonjour();
}
