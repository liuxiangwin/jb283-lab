mvn clean package -DskipTests
java -jar target/inventory-service-swarm.jar -Dswarm.http.port=7070 -Dswarm.management.http.disable=true 
