package com.redhat.training.bookstore.inventory.rest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.jboss.arquillian.junit.Arquillian;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.redhat.training.bookstore.inventory.model.BookInventory;
import com.redhat.training.bookstore.utils.JsonWebTokenUtils;

@RunWith(Arquillian.class)
public class InventoryServiceTest extends TestBase {

	public InventoryServiceTest() {
		super();
	}
	
	private JsonWebTokenUtils utils = new JsonWebTokenUtils();
	
	@Test
	public void testBookInventory() {
		Client client = ClientBuilder.newBuilder().build();
		client.register(new AddAuthorizationHeaderFilter());
		WebTarget target = client.target(this.url.toExternalForm() + "/api/inventory/54321");
		Response response = target.request(MediaType.APPLICATION_JSON).get();
		assertEquals(200, response.getStatus());
		BookInventory inventory = response.readEntity(BookInventory.class);
		assertNotNull(inventory);
		assertEquals("54321", inventory.getIsbn());
		assertEquals((Integer) 21, inventory.getInventory());
	}
	
	@Test
	public void testBookInventoryFailure() {
		Client client = ClientBuilder.newBuilder().build();
		client.register(new AddAuthorizationHeaderFilter());
		WebTarget target = client.target(this.url.toExternalForm() + "/api/inventory/55555");
		Response response = target.request(MediaType.APPLICATION_JSON).get();
		assertEquals(404, response.getStatus());
	}
	
	private class AddAuthorizationHeaderFilter implements ClientRequestFilter {
		
		@Override
		public void filter(ClientRequestContext requestContext) throws IOException {
			
			requestContext.getHeaders().add("Authorization", "Bearer " + getToken());
		}
		
		private String getToken() {
			String token = utils.buildToken("inventory", new String[] {"InventoryHandler"}, 
					"/privateKey.pem", "https://mpconference.com", "a-123", "24400320", 600);
			return token;
		}

	}
}
