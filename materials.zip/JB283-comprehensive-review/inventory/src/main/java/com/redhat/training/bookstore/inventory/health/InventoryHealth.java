package com.redhat.training.bookstore.inventory.health;

import java.util.Date;

import javax.inject.Inject;

import org.eclipse.microprofile.health.Health;
import org.eclipse.microprofile.health.HealthCheck;
import org.eclipse.microprofile.health.HealthCheckResponse;
import org.eclipse.microprofile.health.HealthCheckResponseBuilder;

import com.redhat.training.bookstore.inventory.model.InventoryDatabase;

@Health
public class InventoryHealth implements HealthCheck {

	@Inject
	private InventoryDatabase db;
	
	@Override
	public HealthCheckResponse call() {

		HealthCheckResponseBuilder healthCheckBuilder = 
				HealthCheckResponse.named("inventory-service-check")
				    .withData("catalogSize", db.getInventory().size())
					.withData("lastCheckDate", new Date().toString());
		
		return (db.getInventory().size() == 0) ? 
				healthCheckBuilder.down().build() : healthCheckBuilder.up().build();
	}

}
