package com.redhat.training.bookstore.inventory.model;

import java.net.URL;
import java.util.HashSet;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Singleton;

import org.eclipse.microprofile.config.inject.ConfigProperty;

@Singleton
public class InventoryDatabase {

	@Inject
	private InventoryParser parser;
	
	@Inject
	@ConfigProperty(name = "inventoryFile", defaultValue = "/inventory.json")
	private String inventoryFilename;
	
	private Set<BookInventory> inventories = new HashSet<BookInventory>();
	
	@PostConstruct
	private void loadInventory() {
		URL inventoryUrl = Thread.currentThread().getContextClassLoader().getResource(inventoryFilename);
		this.inventories = parser.parse(inventoryUrl);
	}
	
	public Set<BookInventory> getInventory() {
		return this.inventories;
	}
}
