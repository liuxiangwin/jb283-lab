package com.redhat.training.bookstore.inventory.rest;

import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.redhat.training.bookstore.inventory.model.BookInventory;
import com.redhat.training.bookstore.inventory.model.InventoryDatabase;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Path("/")
@Api("inventory")
@DeclareRoles({"InventoryHandler"})
public class InventoryResource {

	private final Logger log = LoggerFactory.getLogger(InventoryResource.class);
	
	@Inject
	private InventoryDatabase db;
	
	@GET
	@Path("/inventory/{isbn}")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation("Returns the inventory count for a book identified by ISBN")
	@RolesAllowed({"InventoryHandler"})
	public Response getInventory(@PathParam("isbn") String isbn) {
		log.debug("get Inventory endpoint called");
		for (BookInventory inventory : db.getInventory()) {
			if (isbn.equals(inventory.getIsbn()))
				return Response.ok(inventory,MediaType.APPLICATION_JSON).build();
		}
		
		return Response.status(404).build();
	}
}
