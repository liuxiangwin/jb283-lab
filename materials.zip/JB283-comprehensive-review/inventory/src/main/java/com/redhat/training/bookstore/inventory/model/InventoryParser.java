package com.redhat.training.bookstore.inventory.model;

import java.io.IOException;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

import javax.inject.Named;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonReaderFactory;
import javax.json.JsonValue;

@Named
public class InventoryParser {

	public Set<BookInventory> parse(final URL inventoryFile) {
		
		Set<BookInventory> inventories = new HashSet<BookInventory>();
		
		try {
			
			JsonReaderFactory factory = Json.createReaderFactory(null);
			JsonReader reader = factory.createReader(inventoryFile.openStream());
			JsonArray bookArray = reader.readArray();
			
			for (JsonValue inventory : bookArray) {
				inventories.add(new BookInventory((JsonObject) inventory));
			}
			
		} catch (IOException e) {
			System.out.println(e);
		}
		
		return inventories;
	}
}
