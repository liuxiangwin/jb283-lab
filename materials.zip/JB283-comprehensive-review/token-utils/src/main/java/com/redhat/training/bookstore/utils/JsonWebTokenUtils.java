package com.redhat.training.bookstore.utils;

import java.io.InputStream;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

import org.eclipse.microprofile.jwt.Claims;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;

public class JsonWebTokenUtils {
	private final Logger log = LoggerFactory.getLogger(JsonWebTokenUtils.class);
	
	public String buildToken(String username, String[] roles, String privateKeyFile, String issuerName, String tokenId, String subject, Integer expirySeconds) {
		
		log.debug("Creating token for username = " + username + ", roles = " + roles);
		log.debug("issuer name: " + issuerName);
		log.debug("token id: " + tokenId);
		log.debug("subject: " + subject);
		log.debug("expires in (seconds): " + expirySeconds);
		
		// Create token claims
		JSONObject claims = new JSONObject();
		int secs = currentTimeInSecs();
		claims.put(Claims.upn.name(), username);
		claims.put(Claims.preferred_username.name(), username);
		claims.put(Claims.jti.name(), tokenId); //"a-123"
		claims.put(Claims.sub.name(), subject); //"24400320"
		claims.put(Claims.iat.name(), secs);
		claims.put(Claims.auth_time.name(), secs);
		claims.put(Claims.exp.name(), secs + expirySeconds); // 600
		claims.put(Claims.iss.name(), issuerName);  //"https://mpconference.com"
		JSONArray groups = new JSONArray();
		for(String role : roles) {
			groups.add(role);
		}
		claims.put(Claims.groups.name(), groups);
		
		// Sign the token
		try {
			PrivateKey pk = readPrivateKey(privateKeyFile);
			JWSSigner signer = new RSASSASigner(pk);
			JWTClaimsSet claimsSet = JWTClaimsSet.parse(claims);
			JWSHeader jwtHeader = new JWSHeader.Builder(JWSAlgorithm.RS256)
					.keyID(privateKeyFile)
					.type(JOSEObjectType.JWT)
					.build();
			SignedJWT signedToken = new SignedJWT(jwtHeader, claimsSet);
			signedToken.sign(signer);
			String token = signedToken.serialize();
			log.debug("token generated: " + token);
			return token;
		} catch(Exception e) {
			System.out.println("Problem generating token");
			e.printStackTrace();
		}
		
		return null;
	}
	
    private int currentTimeInSecs() {
        long currentTimeMS = System.currentTimeMillis();
        int currentTimeSec = (int) (currentTimeMS / 1000);
        return currentTimeSec;
    }
	
    private PrivateKey readPrivateKey(String pemResName) throws Exception {
        InputStream contentIS = JsonWebTokenUtils.class.getResourceAsStream(pemResName);
        byte[] tmp = new byte[4096];
        int length = contentIS.read(tmp);
        PrivateKey privateKey = decodePrivateKey(new String(tmp, 0, length));
        return privateKey;
    }
    
    private PrivateKey decodePrivateKey(String pemEncoded) throws Exception {
        pemEncoded = removeBeginEnd(pemEncoded);
        byte[] pkcs8EncodedBytes = Base64.getDecoder().decode(pemEncoded);

        // extract the private key

        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(pkcs8EncodedBytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        PrivateKey privKey = kf.generatePrivate(keySpec);
        return privKey;
    }   
    
    private String removeBeginEnd(String pem) {
        pem = pem.replaceAll("-----BEGIN (.*)-----", "");
        pem = pem.replaceAll("-----END (.*)----", "");
        pem = pem.replaceAll("\r\n", "");
        pem = pem.replaceAll("\n", "");
        return pem.trim();
    }
}
