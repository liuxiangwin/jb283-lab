mvn clean package -DskipTests
java -jar target/auth-service-swarm.jar -Dswarm.http.port=6060 -Dswarm.management.http.disable=true 
