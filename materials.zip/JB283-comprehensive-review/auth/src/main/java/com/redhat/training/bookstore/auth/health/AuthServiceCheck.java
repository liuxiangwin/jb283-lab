package com.redhat.training.bookstore.auth.health;

import org.eclipse.microprofile.health.Health;
import org.eclipse.microprofile.health.HealthCheck;
import org.eclipse.microprofile.health.HealthCheckResponse;

@Health
public class AuthServiceCheck implements HealthCheck {

	@Override
	public HealthCheckResponse call() {
		
		return HealthCheckResponse.named("auth-service-check").up().build();
	}

}
