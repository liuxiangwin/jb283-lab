package com.redhat.training.bookstore.auth.rest;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.redhat.training.bookstore.utils.JsonWebTokenUtils;

@Path("/")
@ApplicationScoped
public class AuthorizationResource {

	private final Logger log = LoggerFactory.getLogger(AuthorizationResource.class);

	private JsonWebTokenUtils utils = new JsonWebTokenUtils();
	
	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/auth")
	public Response createToken(String credentials) {
		String creds[] = credentials.split(":");
		if (creds.length == 2) {
			String username = creds[0];
			String password = creds[1];
			String token = null;
			if ("inventory".equals(username) && "mypa55".equals(password)) {
				token = utils.buildToken(username, new String[] {"InventoryHandler"}, 
						"/privateKey.pem", "https://mpconference.com", "a-123", "24400320", 600);
			} else if ("catalog".equals(username) && "mypa55".equals(password)) {
				token = utils.buildToken(username, new String[] {"CatalogHandler"}, 
						"/privateKey.pem", "https://mpconference.com", "a-123", "24400320", 600);
			}
			if (token != null) {
				log.debug("Token successfully built and returned.");
				return Response.ok(token).build();
			}
		}
		return Response.status(403).build();
	}
	

}
