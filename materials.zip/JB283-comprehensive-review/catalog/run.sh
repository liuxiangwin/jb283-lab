mvn clean package -DskipTests
java -jar target/catalog-service-swarm.jar -Dswarm.http.port=8080 -Dswarm.management.http.disable=true -DinventoryPort=7070 -DinventoryHost=localhost -DauthorizationPort=7070 -DauthorizationHost=localhost
