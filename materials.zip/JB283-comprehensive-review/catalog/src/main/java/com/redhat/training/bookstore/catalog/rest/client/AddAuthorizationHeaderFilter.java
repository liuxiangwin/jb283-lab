package com.redhat.training.bookstore.catalog.rest.client;

import java.io.IOException;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;

import org.eclipse.microprofile.config.inject.ConfigProperty;

@ApplicationScoped
public class AddAuthorizationHeaderFilter implements ClientRequestFilter {

	@Inject
	private AuthService service;
	@Inject
	@ConfigProperty(name = "inventoryServiceUsername")
	private String username;
	@Inject
	@ConfigProperty(name = "inventoryServicePassword")
	private String password;
	
	@Override
	public void filter(ClientRequestContext requestContext) throws IOException {
		
		String token = service.createToken(username + ":" + password);
		requestContext.getHeaders().add("Authorization", "Bearer " + token);
		System.out.println("Called inventory with token " + token);
	}

}
