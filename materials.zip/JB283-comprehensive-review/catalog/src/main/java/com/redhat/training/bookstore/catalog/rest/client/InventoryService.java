package com.redhat.training.bookstore.catalog.rest.client;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.redhat.training.bookstore.catalog.model.BookInventory;

public interface InventoryService {

	@Path("inventory/{isbn}")
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	public BookInventory getInventory(@PathParam("isbn") String isbn);
}
