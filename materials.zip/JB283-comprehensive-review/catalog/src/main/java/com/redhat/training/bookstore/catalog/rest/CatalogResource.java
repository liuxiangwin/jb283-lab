package com.redhat.training.bookstore.catalog.rest;

import java.util.Set;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.NotAuthorizedException;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.metrics.Counter;
import org.eclipse.microprofile.metrics.MetricUnits;
import org.eclipse.microprofile.metrics.annotation.Metric;
import org.eclipse.microprofile.metrics.annotation.Timed;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.redhat.training.bookstore.catalog.model.Book;
import com.redhat.training.bookstore.catalog.model.BookDatabase;
import com.redhat.training.bookstore.catalog.model.BookInventory;
import com.redhat.training.bookstore.catalog.rest.client.InventoryService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Path("/")
@Api("catalog")
public class CatalogResource {
	
	private final Logger log = LoggerFactory.getLogger(CatalogResource.class);
	
	@Inject
	private BookDatabase db;
	
	@Inject
	private InventoryService inventoryService;
	
	@Inject
	@Metric(name = "failureCount", description = "Number of times the inventory endpoint fails",
			displayName="InventoryLookupFailureCount", absolute=true)
	private Counter failedCount;
	
	@GET
	@Path("/books")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation("Returns the list of books in the catalog")
	public Set<Book> getBooks(){
		log.debug("Books endpoint called.");
		return db.getBooks();
	}
	
	@GET
	@Path("/bookinventory/{isbn}")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation("Return a book with its inventory count")
	@Timed(absolute=true, unit = MetricUnits.MILLISECONDS, name = "inventoryTimer", displayName = "inventoryTimer",
		description = "Invocation time for getting book inventory")
	@Timeout(3000)
	@Fallback(fallbackMethod="getBookWithDefaultInventory")
	public Response getBookWithInventory(@PathParam("isbn") String isbn) {
		
		for(Book book : db.getBooks()) {
			if (isbn.equals(book.getIsbn())) {
				try {
					BookInventory inventory = inventoryService.getInventory(isbn);
					if (inventory == null)
						book.setInventory(0);
					else
						book.setInventory(inventory.getInventory());
					return Response.ok(book, MediaType.APPLICATION_JSON).build();	
				} catch(NotAuthorizedException e) {
					log.error("Inventory service call failed. Unauthorized.");
					throw e;
				}
			}
		}
		return Response.status(404).build();
	}
	
	@SuppressWarnings("unused")
	private Response getBookWithDefaultInventory(String isbn) {
		
		failedCount.inc();
		for(Book book : db.getBooks()) {
			if (isbn.equals(book.getIsbn())) {
				book.setInventory(-1);
				return Response.ok(book, MediaType.APPLICATION_JSON).build();	
			}
		}
		return Response.status(404).build();
	}
}
