package com.redhat.training.bookstore.catalog.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.json.JsonObject;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Book implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String bookTitle;
	private String isbn;
	private BigDecimal price;
	private Integer inventory = 0;

	public Book() {
		
	}
	
	public Book(JsonObject book) {
		this.bookTitle = book.getString("bookTitle");
		this.isbn = book.getString("isbn");
		this.price = book.getJsonNumber("price").bigDecimalValue();
	}

	public void setInventory(Integer inventory) {
		this.inventory = inventory;
	}

	public Integer getInventory() {
		return this.inventory;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((isbn == null) ? 0 : isbn.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (isbn == null) {
			if (other.isbn != null)
				return false;
		} else if (!isbn.equals(other.isbn))
			return false;
		return true;
	}	
}
