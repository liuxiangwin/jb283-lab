package com.redhat.training.bookstore.catalog.health;

import java.util.Date;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import org.eclipse.microprofile.health.Health;
import org.eclipse.microprofile.health.HealthCheck;
import org.eclipse.microprofile.health.HealthCheckResponse;
import org.eclipse.microprofile.health.HealthCheckResponseBuilder;

import com.redhat.training.bookstore.catalog.model.BookDatabase;

@Health
@ApplicationScoped
public class CatalogServiceCheck implements HealthCheck {

	@Inject
	private BookDatabase db;
	
	@Override
	public HealthCheckResponse call() {

		HealthCheckResponseBuilder healthCheckBuilder = 
				HealthCheckResponse.named("catalog-service-check")
				    .withData("catalogSize", db.getBooks().size())
					.withData("lastCheckDate", new Date().toString());
		
		return (db.getBooks().size() == 0) ? 
				healthCheckBuilder.down().build() : healthCheckBuilder.up().build();
	}

}
