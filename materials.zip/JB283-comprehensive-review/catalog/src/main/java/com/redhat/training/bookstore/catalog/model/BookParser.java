package com.redhat.training.bookstore.catalog.model;

import java.io.IOException;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

import javax.inject.Named;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonReaderFactory;
import javax.json.JsonValue;

@Named
public class BookParser {

	public Set<Book> parse(final URL bookFile) {

		Set<Book> books = new HashSet<Book>();

		try {
			
			JsonReaderFactory factory = Json.createReaderFactory(null);
			JsonReader reader = factory.createReader(bookFile.openStream());
			JsonArray bookArray = reader.readArray();
			
			for (JsonValue book : bookArray) {
				books.add(new Book((JsonObject) book));
			}
			
		} catch (IOException e) {
			System.out.println(e);
		}

		return books;

	}

}
