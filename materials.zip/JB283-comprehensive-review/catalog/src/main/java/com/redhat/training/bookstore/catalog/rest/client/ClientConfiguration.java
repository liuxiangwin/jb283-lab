package com.redhat.training.bookstore.catalog.rest.client;

import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Singleton;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientConfiguration {
	
	private final Logger log = LoggerFactory.getLogger(ClientConfiguration.class);
	
	@Inject
	@ConfigProperty(name = "inventoryPort", defaultValue = "8080")
	private String inventoryPort;
	
	@Inject
	@ConfigProperty(name = "inventoryHost", defaultValue = "inventory-service")
	private String inventoryHost;
	
	@Inject
	@ConfigProperty(name = "authorizationPort", defaultValue = "8080")
	private String authorizationPort;
	
	@Inject
	@ConfigProperty(name = "authorizationHost", defaultValue = "auth-service")
	private String authorizationHost;
	
	@Inject
	private AddAuthorizationHeaderFilter filter;
	
	@Produces
	@Singleton
	public InventoryService inventoryService() {
		Client client = ClientBuilder.newClient();
		client.register(filter);
		WebTarget target = client.target("http://" + inventoryHost + ":" + inventoryPort + "/api");
		log.info("inventory service will be invoked at: " + target.getUri());
		ResteasyWebTarget rtarget = (ResteasyWebTarget) target;
		InventoryService service = rtarget.proxy(InventoryService.class);
		return service;
	}
	
	@Produces
	@Singleton
	public AuthService authService() {
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target("http://" + authorizationHost + ":" + authorizationPort + "/api");
		log.info("auth service will be invoked at: " + target.getUri());
		ResteasyWebTarget rtarget = (ResteasyWebTarget) target;
		AuthService service = rtarget.proxy(AuthService.class);
		return service;
	}
}
