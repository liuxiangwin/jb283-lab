package com.redhat.training.bookstore.catalog.model;

import java.net.URL;
import java.util.HashSet;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Singleton;

import org.eclipse.microprofile.config.inject.ConfigProperty;

@Singleton
public class BookDatabase {

	@Inject
	private BookParser parser;
	
	@Inject
	@ConfigProperty(name = "bookFile", defaultValue = "/books.json")
	private String bookFilename;
	
	private Set<Book> books = new HashSet<Book>();
	
	@PostConstruct
	private void loadBooks() {
		URL bookUrl = Thread.currentThread().getContextClassLoader().getResource(bookFilename);
		this.books = parser.parse(bookUrl);
	}
	
	public Set<Book> getBooks() {
		return this.books;
	}
}
