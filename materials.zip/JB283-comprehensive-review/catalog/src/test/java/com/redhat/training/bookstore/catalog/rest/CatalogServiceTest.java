package com.redhat.training.bookstore.catalog.rest;

import static org.junit.Assert.assertEquals;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.allOf;

import java.util.Set;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.jboss.arquillian.junit.Arquillian;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.redhat.training.bookstore.catalog.model.Book;


@RunWith(Arquillian.class)
public class CatalogServiceTest extends TestBase {

	public CatalogServiceTest() {
		super();
	}
	
	@Rule
	public WireMockRule rule = new WireMockRule(options().port(7070));
	@Rule
	public WireMockRule authRule = new WireMockRule(options().port(6060));
	
	@Test
	public void testBookList() {
		Client client = ClientBuilder.newBuilder().build();
		WebTarget target = client.target(this.url.toExternalForm() + "/api/books");
		Response response = target.request(MediaType.APPLICATION_JSON).get();
		assertEquals(200, response.getStatus());
		//System.out.println(response.readEntity(String.class));
		Set<Book> books = response.readEntity(new GenericType<Set<Book>>() {});
		assertEquals(2, books.size());
		int count = 0;
		for (Book book : books) {
			if (book.getIsbn().equals("12345")) {
				++count;
				assertEquals("Gone with the Wind", book.getBookTitle());
			} else if (book.getIsbn().equals("54321")) {
				++count;
				assertEquals("Wuthering Heights", book.getBookTitle());
			}
		} 
		assertEquals("Not all expected books were returned", 2, count);
	}
	
	@Test
	public void testBookInventory() {
		rule.stubFor(get(urlMatching("/api/inventory/12345"))
				.willReturn(aResponse().withStatus(200).withHeader("Content-Type","application/json")
				.withBody("{\"isbn\":\"12345\",\"inventory\":12}")));
		
		authRule.stubFor(post(urlMatching("/api/auth"))
				.withRequestBody(equalTo("inventory:mypa55"))
				.willReturn(aResponse().withStatus(200).withHeader("Content-Type","text/plain")
				.withBody("dummy token")));
		
		given().when().get("/api/bookinventory/12345")
			.then().body(
					allOf(containsString("inventory\":12"),
						  containsString("bookTitle\":\"Gone with the Wind\""))); 
			
	}
	
	@Test
	public void testBookInventoryFailure() {
		
		given().when().get("/api/bookinventory/55555")
			.then().statusCode(404); 
			
	}
	
}
