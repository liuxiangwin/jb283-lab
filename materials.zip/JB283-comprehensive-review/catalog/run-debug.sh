mvn wildfly-swarm:run -DskipTests -DinventoryPort=7070 -DinventoryHost=localhost -Dswarm.debug.port=8888 -Dswarm.management.http.disable=true 
