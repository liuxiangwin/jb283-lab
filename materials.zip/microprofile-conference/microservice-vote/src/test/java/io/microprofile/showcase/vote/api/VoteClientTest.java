/*
 * Copyright (c) 2016 IBM, and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.microprofile.showcase.vote.api;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.container.test.api.RunAsClient;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.wildfly.swarm.Swarm;
import org.wildfly.swarm.arquillian.CreateSwarm;

import io.microprofile.showcase.vote.ArquillianTestUtils;
import io.microprofile.showcase.vote.model.Attendee;
import io.microprofile.showcase.vote.model.SessionRating;

@RunWith(Arquillian.class)
public class VoteClientTest {

	
	private static String ROOT_URL = "http://localhost:8080/vote";//+ System.getProperty("liberty.test.port") + "/" + System.getProperty("app.context.root");
    private static String RATE_URL = ROOT_URL + "/rate";
    private static String RATE_BY_SESSION_URL = ROOT_URL + "/ratingsBySession";
    private static String AVG_RATE_BY_SESSION_URL = ROOT_URL + "/averageRatingBySession";
    private static String RATE_BY_ATTENDEE_URL = ROOT_URL + "/ratingsByAttendee";
    private Client attendeeClient;
    private Client ratingClient;
    
	@Deployment
	public static WebArchive createWebArchive() {
		WebArchive addAsManifestResource = ArquillianTestUtils.deploy();
		System.out.println(addAsManifestResource.toString(true));
		return addAsManifestResource;
	}


	@CreateSwarm
	public static Swarm newContainer() throws Exception {
		Swarm newContainer = ArquillianTestUtils.newContainer();
		return newContainer;
	}


    @Before
    public void clearDatabase() {
    	attendeeClient = new ResteasyClientBuilder().build();
        attendeeClient.register(AttendeeProvider.class);
        attendeeClient.register(AttendeeListProvider.class);
        ratingClient = new ResteasyClientBuilder().build();
        ratingClient.register(SessionRatingProvider.class);
        ratingClient.register(SessionRatingListProvider.class);

        deleteAllAttendees();
        deleteAllRatings();
    }

    @Test
	@RunAsClient
    public void testRegisterAttendee() {
        // Register attendee and verify that the returned name matches the name submitted
        Attendee attendee = registerAttendee("Adam Smith");
        assertEquals("Registered attendees name does not match name submitted", "Adam Smith", attendee.getName());

        // Register another attendee and verify that the IDs are not the same
        Attendee attendee2 = registerAttendee("Sally Smith");
        assertNotEquals("Mulitple registered attendees have the same ID", attendee.getId(), attendee2.getId());
    }

    @Test
    @RunAsClient
    public void testUpdateAttendee() {
        // Register attendee with full name
        Attendee originalAttendee = registerAttendee("Josef Chechov");

        // Update with nickname
        Attendee updatedAttendee = new Attendee(originalAttendee.getId(), "Joe Chechov");
        updatedAttendee = updateAttendee(updatedAttendee);

        assertEquals("Unexpected name for updated attendee", "Joe Chechov", updatedAttendee.getName());
        assertEquals("Unexpected change of ID when updating attendee name", originalAttendee.getId(), updatedAttendee.getId());
    }

    @Test
    @RunAsClient
    public void testRateUpdateAndCheckSession() throws Exception {
        // Register attendees
        Attendee attendee1 = registerAttendee("Tyrone Watson");
        Attendee attendee2 = registerAttendee("Maria Iglesia");

        // Rate sessions
        SessionRating sr1 = rateSessionAndCheck(new SessionRating("Microprofile: The Next Big Thing", attendee1.getId(), 9));
        SessionRating sr2 = rateSessionAndCheck(new SessionRating("Microprofile: The Next Big Thing", attendee2.getId(), 8));
        @SuppressWarnings("unused")
		SessionRating sr3 = rateSessionAndCheck(new SessionRating("What's coming in Java EE 8?", attendee1.getId(), 7));
        SessionRating sr4 = rateSessionAndCheck(new SessionRating("What's coming in Java EE 8?", attendee2.getId(), 8));
        SessionRating sr5 = rateSessionAndCheck(new SessionRating("OSGi Basics", attendee1.getId(), 4));
        @SuppressWarnings("unused")
		SessionRating sr6 = rateSessionAndCheck(new SessionRating("What is WebSphere Liberty?", attendee1.getId(), 10));
        SessionRating sr7 = rateSessionAndCheck(new SessionRating("What is WebSphere Liberty?", attendee2.getId(), 10));

        // Update a session
        SessionRating newSr5 = updateRating(new SessionRating(sr5.getId(), sr5.getSession(), sr5.getAttendeeId(), 6));
        assertEquals("Unexpected rating value from updated SessionRating", 6, newSr5.getRating());

        // Check rating for a given session
        List<SessionRating> ratingsForMicroprofile = listAllRatingsBySession("Microprofile: The Next Big Thing");
        assertEquals("The returned list of Microprofile session ratings contains an unexpected number of entries", 2,
                     ratingsForMicroprofile.size());

        assertTrue("The returned ratings for the Microprofile session do not contain the expected ratings."
                , ratingsForMicroprofile.contains(sr1) && ratingsForMicroprofile.contains(sr2));

        // Check the average rating for a different session
        double avg = getAverageRatingsBySession("What's coming in Java EE 8?");
        assertEquals("Unexpected average rating for Java EE8 session", 7.5, avg, 0.0);

        // Check rating for a given attendee
        List<SessionRating> ratingsFromAttendee2 = listAllRatingsByAttendee(attendee2);
        assertEquals("The returned list of attendee2's session ratings contains an unexpected number of entries", 3,
                     ratingsFromAttendee2.size());
        assertTrue("The returned ratings from attendee2 do not contain the expected ratings",
                   ratingsFromAttendee2.contains(sr2) && ratingsFromAttendee2.contains(sr4) && ratingsFromAttendee2.contains(sr7));

    }

    @Test
    @RunAsClient
    public void testDeployment() {
    	checkRoot("Microservice Session Vote Application");
    }
    
    private static String ATTENDEE_URL = ROOT_URL + "/attendee";



    public void deleteAllAttendees() {
        UriBuilder uriBuilder = UriBuilder.fromPath(ATTENDEE_URL);
        Response response = attendeeClient.target(uriBuilder).request(MediaType.APPLICATION_JSON).get();
        @SuppressWarnings("unchecked")
        List<Attendee> attendees = response.readEntity(List.class);
        List<String> attendeeIds = new ArrayList<String>();
        for (Attendee attendee : attendees) {
            attendeeIds.add(attendee.getId());
        }
        for (String id : attendeeIds) {
            deleteAttendee(id);
        }
    }

    private void deleteAttendee(String attendeeId) {
        UriBuilder uriBuilder = UriBuilder.fromPath(ATTENDEE_URL + "/" + attendeeId);
        Response response = attendeeClient.target(uriBuilder).request(MediaType.APPLICATION_JSON).delete();
        assertEquals("Deletion of attendee " + attendeeId + " failed.", 204, response.getStatus());
    }

    private void checkResponseStatus(Response response) {
        assertEquals("Response status was " + response.getStatus(), 200, response.getStatus());
    }

    public Attendee registerAttendee(String name) {
        UriBuilder uriBuilder = UriBuilder.fromPath(ATTENDEE_URL);
        JsonObject jsonName = Json.createObjectBuilder().add("name", name).build();
        Response r = attendeeClient.target(uriBuilder).request(MediaType.APPLICATION_JSON).post(Entity.json(jsonName.toString()));
        checkResponseStatus(r);
        Attendee registeredAttendee = r.readEntity(Attendee.class);
        return registeredAttendee;
    }

    public Attendee updateAttendee(Attendee attendee) {
        UriBuilder uriBuilder = UriBuilder.fromPath(ATTENDEE_URL + "/" + attendee.getId());
        Response r = attendeeClient.target(uriBuilder).request(MediaType.APPLICATION_JSON).put(Entity.json(attendee));
        Attendee updatedAttendee = r.readEntity(Attendee.class);
        return updatedAttendee;
    }


	public void checkRoot(String expectedOutput) {
		UriBuilder uriBuilder = UriBuilder.fromPath(ROOT_URL);
		Response response = attendeeClient.target(uriBuilder).request().get();
        String responseString = response.readEntity(String.class);
        response.close();
        assertTrue("Incorrect response, response is " + responseString, responseString.contains(expectedOutput));
	}



    public void deleteAllRatings() {
        UriBuilder uriBuilder = UriBuilder.fromPath(RATE_URL);
        Response response = ratingClient.target(uriBuilder).request(MediaType.APPLICATION_JSON).get();
        @SuppressWarnings("unchecked")
        List<SessionRating> ratings = response.readEntity(List.class);
        List<String> ratingIds = new ArrayList<String>();
        for (SessionRating rating : ratings) {
            ratingIds.add(rating.getId());
        }
        for (String id : ratingIds) {
            deleteRating(id);
        }
    }

    private void deleteRating(String ratingId) {
        UriBuilder uriBuilder = UriBuilder.fromPath(RATE_URL + "/" + ratingId);
        Response response = ratingClient.target(uriBuilder).request(MediaType.APPLICATION_JSON).delete();
        assertEquals("Deletion of attendee " + ratingId + " failed.", 204, response.getStatus());
    }

    public SessionRating rateSession(SessionRating rating) {
        UriBuilder uriBuilder = UriBuilder.fromPath(RATE_URL);
        Response r = ratingClient.target(uriBuilder).request(MediaType.APPLICATION_JSON).post(Entity.json(rating));
        SessionRating updatedRating = r.readEntity(SessionRating.class);
        return updatedRating;
    }

    public SessionRating updateRating(SessionRating rating) {
        UriBuilder uriBuilder = UriBuilder.fromPath(RATE_URL + "/" + rating.getId());
        Response r = ratingClient.target(uriBuilder).request(MediaType.APPLICATION_JSON).put(Entity.json(rating));
        SessionRating updatedRating = r.readEntity(SessionRating.class);
        return updatedRating;
    }

    public List<SessionRating> listAllRatingsBySession(String session) throws IOException {
        UriBuilder uriBuilder = UriBuilder.fromPath(RATE_BY_SESSION_URL).queryParam("sessionId", session);
        Response r = ratingClient.target(uriBuilder).request(MediaType.APPLICATION_JSON).get();
        @SuppressWarnings("unchecked")
        List<SessionRating> ratings = r.readEntity(List.class);
        return ratings;
    }

    public double getAverageRatingsBySession(String session) throws IOException {
        UriBuilder uriBuilder = UriBuilder.fromPath(AVG_RATE_BY_SESSION_URL).queryParam("sessionId", session);
        Response r = ratingClient.target(uriBuilder).request().get();
        String string = r.readEntity(String.class);
        Double d = Double.parseDouble(string);
        return d;
    }

    public List<SessionRating> listAllRatingsByAttendee(Attendee attendee) throws IOException {
        UriBuilder uriBuilder = UriBuilder.fromPath(RATE_BY_ATTENDEE_URL).queryParam("attendeeId", attendee.getId());
        Response r = ratingClient.target(uriBuilder).request(MediaType.APPLICATION_JSON).get();
        @SuppressWarnings("unchecked")
        List<SessionRating> ratings = r.readEntity(List.class);
        return ratings;
    }

    public SessionRating rateSessionAndCheck(SessionRating rating) {
        SessionRating returnedRating = rateSession(rating);
        assertEquals("Unexpected session from returned SessionRating", rating.getSession(), returnedRating.getSession());
        assertEquals("Unexpected attendee ID from returned SessionRating", rating.getAttendeeId(), returnedRating.getAttendeeId());
        assertEquals("Unexpected rating value from returned SessionRating", rating.getRating(), returnedRating.getRating());
        return returnedRating;
    }


}
