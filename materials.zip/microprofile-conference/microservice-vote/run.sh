#!/bin/bash
/usr/bin/java -jar target/microservice-vote-liberty.jar
