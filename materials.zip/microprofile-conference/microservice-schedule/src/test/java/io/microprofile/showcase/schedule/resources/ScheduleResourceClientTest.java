/*
 * Copyright(c) 2016-2017 IBM, Red Hat, and others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *      http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.microprofile.showcase.schedule.resources;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.hasItems;

import java.io.File;
import java.net.MalformedURLException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Properties;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.container.test.api.RunAsClient;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.junit.InSequence;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.jboss.shrinkwrap.resolver.api.maven.Maven;
import org.jboss.shrinkwrap.resolver.api.maven.ScopeType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.wildfly.swarm.Swarm;
import org.wildfly.swarm.arquillian.CreateSwarm;

import io.microprofile.showcase.schedule.model.Schedule;
import io.restassured.http.ContentType;

@RunWith(Arquillian.class)
public class ScheduleResourceClientTest {

	private static final String TEST_SESSION = String.valueOf(12);
	private static final String TEST_VENUE = "Metropolis";


	@Deployment
	public static WebArchive createDeployment() {

		File[] deps = Maven.resolver().loadPomFromFile("pom.xml")
				.importDependencies(ScopeType.COMPILE, ScopeType.RUNTIME).resolve().withTransitivity()
				.asFile();
		return ShrinkWrap.create(WebArchive.class, "schedule-microservice.war")
				.addPackages(true, "io.microprofile.showcase.schedule")
				// .addClasses(ScheduleResource.class, ScheduleDAO.class, Application.class)
				.addAsLibraries(deps);
	}

	@CreateSwarm
	public static Swarm newContainer() throws Exception {
		Properties properties = new Properties();
		properties.put("swarm.http.port", 6060);
		properties.put("java.util.logging.manager", "org.jboss.logmanager.LogManager");
		Swarm swarm = new Swarm(properties);
		return swarm.withProfile("defaults");
	}

	@Test
	@RunAsClient
	@InSequence(1)
	public void shouldCreateSchedule() throws Exception {
		String scheduleId = createScheduledSession(TEST_SESSION, TEST_VENUE, String.valueOf(400), LocalDate.now(),
				LocalTime.now());
		given().get("/schedule/" + scheduleId).then().statusCode((200)).contentType(ContentType.JSON)
				.body("sessionId", equalTo(TEST_SESSION)).body("id", equalTo(scheduleId))
				.body("venue", equalTo(TEST_VENUE));

	}


	@Test
	@RunAsClient
	@InSequence(2)
	public void shouldGetActiveScheduledSessions() throws Exception {
		final String webServices = String.valueOf(100);
		final String designPatterns = String.valueOf(120);
		final String java = String.valueOf(140);

		createScheduledSession(webServices, "Moscone", String.valueOf(600), LocalDate.of(1995, 9, 20),
				LocalTime.of(16, 0));
		createScheduledSession(designPatterns, "Moscone", String.valueOf(600), LocalDate.of(1995, 9, 20),
				LocalTime.of(17, 0));
		createScheduledSession(java, "Moscone", String.valueOf(600), LocalDate.of(1995, 9, 21), LocalTime.of(16, 0));

		given().when().get("/schedule/active/" + LocalDateTime.of(1995, 9, 20, 17, 34, 29)).then().statusCode((200))
				.contentType(ContentType.JSON).body("startTime", hasItems("17:00"))
				.body("startTime.size()", equalTo(1));
	}

	@Test
	@RunAsClient
	@InSequence(3)
	public void shouldGetScheduledSessionsByDate() throws Exception {
		given().when().get("/schedule/all/" + LocalDate.of(1995, 9, 20)).then().statusCode((200))
				.contentType(ContentType.JSON).body("startTime.size()", equalTo(2))
				.body("startTime", hasItems("17:00", "16:00"));

	}

	@Test
	@RunAsClient
	@InSequence(4)
	public void shouldRemoveSchedule() throws Exception {

		final String removeMe = String.valueOf(200);

		String removeId = createScheduledSession(removeMe, "Far far away", String.valueOf(666), LocalDate.now(),
				LocalTime.now());

		given().when().delete("/schedule/" + removeId).then().statusCode((204));

		given().when().get("/schedule/" + removeId).then().statusCode((404));

	}

	private String createScheduledSession(final String session, final String venue, final String venueId,
			final LocalDate date, final LocalTime time) throws MalformedURLException {
		final Schedule schedule = new Schedule(session, venue, venueId, date, time, Duration.ofHours(1L));
		String scheduleId = given().body(schedule).contentType(ContentType.JSON).when().post("/schedule").then()
				.statusCode((201)).extract().path("id");
		return scheduleId;

	}
}
