#!/bin/bash
mvn clean package -DskipTests -Pwildfly wildfly-swarm:run -Dswarm.http.port=8083 -Dswarm.management.http.disable=true

