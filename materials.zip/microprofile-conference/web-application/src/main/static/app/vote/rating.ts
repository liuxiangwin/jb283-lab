//This is the same model our service emits
export class Rating {
    id: string;
    session: string;
    attendeeId: number;
    rating: number;
}
