export class Attendee {
    id: string;
    name: string;
}
