export {VotesComponent} from './votes.component';
export {VoteComponent} from './vote.component';
export {VoteService} from './vote.service';
export {Rating} from "./rating";