export class Endpoint {
    name: string;
    url: string;
}
