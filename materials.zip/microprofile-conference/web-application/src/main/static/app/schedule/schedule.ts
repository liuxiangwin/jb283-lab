//This is the same model our service emits
export class Schedule {
    date: string;
    duration: string;
    venue: string;
    venueId: string;
    startTime: string;
    id: string;
    sessionId: string;
}
