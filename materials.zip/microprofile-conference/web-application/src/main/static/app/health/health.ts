import {Endpoint} from "../shared/endpoint";

export class Health {
    id: string;
    ep: Endpoint;
    check: any;
}
