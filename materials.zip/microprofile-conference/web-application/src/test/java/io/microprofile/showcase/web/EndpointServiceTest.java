/*
 * Copyright(c) 2016-2017 IBM, Red Hat, and others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.microprofile.showcase.web;


import io.restassured.http.ContentType;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.container.test.api.RunAsClient;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.jboss.shrinkwrap.resolver.api.maven.Maven;
import org.jboss.shrinkwrap.resolver.api.maven.ScopeType;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.wildfly.swarm.Swarm;
import org.wildfly.swarm.arquillian.CreateSwarm;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;

import java.io.File;
import java.util.Properties;
import static io.restassured.RestAssured.*;



@RunWith(Arquillian.class)
public class EndpointServiceTest extends Assert {

    @Deployment
    public static WebArchive createDeployment() {


        File[] deps = Maven.resolver().loadPomFromFile("pom.xml").importDependencies(ScopeType.COMPILE, ScopeType.RUNTIME).resolve().withTransitivity().asFile();

        WebArchive libs = ShrinkWrap.create(WebArchive.class, "web.war")
            .addPackages(true, "io.microprofile.showcase.web")
            .addAsWebInfResource(new File("src/main/local/webapp/WEB-INF/conference.properties"), "conference.properties")
            .addAsLibraries(deps)
            ;
        return libs;
    }

    @CreateSwarm
    public static Swarm newContainer() throws Exception {
        Properties properties = new Properties();
		//properties.put("swarm.http.port", 8083);
        properties.put("java.util.logging.manager", "org.jboss.logmanager.LogManager");
        Swarm swarm = new Swarm(properties);
        return swarm.withProfile("defaults");
    }

    @Test
    @RunAsClient
    public void getConferenceEndpoints() throws Exception {
        given()
            .when()
                .get("/service/endpoints/list")
            .then()
                .statusCode((200))
                .contentType(ContentType.JSON)
                .body("endpoints.size()",is(15));
    }

}
