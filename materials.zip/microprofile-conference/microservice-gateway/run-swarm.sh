#!/bin/bash
mvn clean package -Pwildfly -DskipTests wildfly-swarm:run -Dswarm.http.port=6055 -Dswarm.management.http.disable=true #-Dswarm.debug.port=60509
