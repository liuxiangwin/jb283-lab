package io.microprofile.showcase.proxy;

import java.util.Collection;
import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import io.microprofile.showcase.model.Speaker;

@Produces({MediaType.APPLICATION_JSON})
@Consumes(MediaType.APPLICATION_JSON)
@Path("speaker")
public interface SpeakerResource {

	@GET
	public Collection<Speaker> getAllSpeakers();
	
	@POST
    @Path("/add")
    public Speaker add(final Speaker speaker);

    @DELETE
    @Path("/remove/{id}")
    public void remove(@PathParam("id") final String id);

    @PUT
    @Path("/update")
    public Speaker update(final Speaker speaker);

    @GET
    @Path("/retrieve/{id}")
    public Speaker retrieve(@PathParam("id") final String id);

    @PUT
    @Path("/search")
    public Set<Speaker> search(final Speaker speaker);

}
