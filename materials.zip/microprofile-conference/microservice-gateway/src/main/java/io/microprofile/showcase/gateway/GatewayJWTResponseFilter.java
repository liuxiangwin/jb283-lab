package io.microprofile.showcase.gateway;

import java.io.IOException;

import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import javax.ws.rs.client.ClientResponseContext;
import javax.ws.rs.client.ClientResponseFilter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.ext.Provider;

import org.eclipse.microprofile.jwt.JsonWebToken;

@Provider
public class GatewayJWTResponseFilter implements ClientRequestFilter, ClientResponseFilter {

	private JsonWebToken principal;
	
	public GatewayJWTResponseFilter() {
		principal = null;
	}
	
	public GatewayJWTResponseFilter(SecurityContext securityContext) {
		
		principal = (JsonWebToken) securityContext.getUserPrincipal();
		
	}
	
	// implement the ClientRequestFilter.filter method
	@Override
	public void filter(ClientRequestContext requestContext) throws IOException {
		if(principal != null) {
			System.out.println("Setting Principal!!");
			requestContext.getHeaders().add(HttpHeaders.AUTHORIZATION, "Bearer " + principal.getRawToken());
		}else {
			System.out.println("No principal!!");
		}
	}

	// implement the ClientResponseFilter.filter method
	@Override
	public void filter(ClientRequestContext requestContext, ClientResponseContext responseContext) throws IOException {

	}
}

