package io.microprofile.showcase.proxy;

import java.util.Collection;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import io.microprofile.showcase.model.Schedule;


@Path("/schedule")
@Produces("application/json")
public interface ScheduleResource {
	
	@POST
    @Consumes("application/json")
    public Response add(final Schedule schedule);

    @GET
    @Path("/{id}")
    public Response retrieve(@PathParam("id") final String id);

    @GET
    @Path("/all")
    public Collection<Schedule> allSchedules();

    @GET
    @Path("/venue/{id}")
    public Collection<Schedule> allForVenue(@PathParam("id") final String id);

    @GET
    @Path("/active/{dateTime}")
    public Collection<Schedule> activeAtDate(@PathParam("dateTime") final String dateTimeString);

    @GET
    @Path("/all/{date}")
    public Collection<Schedule> allForDay(@PathParam("date") final String dateString);

    @DELETE
    @Path("/{scheduleId}")
    public Response remove(@PathParam("scheduleId") final String scheduleId);

}
