package io.microprofile.showcase.proxy;

import java.util.Collection;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import io.microprofile.showcase.model.Session;


@Path("sessions")
public interface SessionResource {

	@GET
	@Consumes(MediaType.MEDIA_TYPE_WILDCARD)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/")
	public Collection<Session> allSessions();
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/")
	public Session createSession(Session session);
	
	@GET
	@Consumes(MediaType.MEDIA_TYPE_WILDCARD)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{sessionId}")
	public Session getSession(@PathParam("sessionId")String sessionId);
	
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{sessionId}")
	public Session updateSession(@PathParam("sessionId")String sessionId, Session session);
	
	@DELETE
	@Consumes(MediaType.MEDIA_TYPE_WILDCARD)
	@Path("/{sessionId}")
	public Response deleteSession(@PathParam("sessionId")String sessionId);
	
	@GET
	@Consumes(MediaType.MEDIA_TYPE_WILDCARD)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{sessionId}/speakers")
	public Response getSessionSpeakers(@PathParam("sessionId")String sessionId);
	
	@PUT
	@Consumes(MediaType.MEDIA_TYPE_WILDCARD)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{sessionId}/speakers/{speakerId}")
	public Session addSessionSpeaker(@PathParam("sessionId")String sessionId, @PathParam("speakerId")String speakerId);
	
	@DELETE
	@Consumes(MediaType.MEDIA_TYPE_WILDCARD)
	@Path("/{sessionId}/speakers/{speakerId}")
	public Response removeSessionSpeaker(@PathParam("sessionId")String sessionId, @PathParam("speakerId")String speakerId);
}
