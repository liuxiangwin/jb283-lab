package io.microprofile.showcase.gateway;

import javax.annotation.security.PermitAll;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;

import io.microprofile.showcase.model.Schedule;
import io.microprofile.showcase.proxy.ScheduleResource;

@SuppressWarnings("cdi-ambiguous-dependency")
@PermitAll
@Path("gateway/schedule")
@ApplicationScoped
@Consumes(MediaType.MEDIA_TYPE_WILDCARD)
@Produces(MediaType.APPLICATION_JSON)
public class GatewayScheduleResource {
	
	@Inject
	@ConfigProperty(name="scheduleURL", defaultValue="http://localhost:6060")
	private String scheduleURL;
	
	private ScheduleResource buildClient(SecurityContext context) {
		System.out.println("Building new client");
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(scheduleURL);
		ResteasyWebTarget restEasyTarget = (ResteasyWebTarget)target;
		restEasyTarget.register(new GatewayJWTResponseFilter(context));
		return restEasyTarget.proxy(ScheduleResource.class);
		
	}
	
	@POST
    @Consumes("application/json")
    public Response add(@Context SecurityContext securityContext,final Schedule schedule) {
		ScheduleResource proxy = buildClient(securityContext);
		return proxy.add(schedule);
	}

    @GET
    @Path("/{id}")
    public Response retrieve(@Context SecurityContext securityContext, @PathParam("id") final String id) {
    	ScheduleResource proxy = buildClient(securityContext);
		return proxy.retrieve(id);
    }

    @GET
    @Path("/all")
    public Response allSchedules(@Context SecurityContext securityContext) {
    	ScheduleResource proxy = buildClient(securityContext);
    	return Response.ok(proxy.allSchedules()).build();
    }

    @GET
    @Path("/venue/{id}")
    public Response allForVenue(@Context SecurityContext securityContext, @PathParam("id") final String id) {
    	ScheduleResource proxy = buildClient(securityContext);
    	return Response.ok(proxy.allForVenue(id)).build();
    }

    @GET
    @Path("/active/{dateTime}")
    public Response activeAtDate(@Context SecurityContext securityContext, @PathParam("dateTime") final String dateTimeString) {
    	ScheduleResource proxy = buildClient(securityContext);
    	return Response.ok(proxy.activeAtDate(dateTimeString)).build();
    }

    @GET
    @Path("/all/{date}")
    public Response allForDay(@Context SecurityContext securityContext, @PathParam("date") final String dateString){
    	ScheduleResource proxy = buildClient(securityContext);
    	return Response.ok(proxy.allForDay(dateString)).build();
    }

    @DELETE
    @Path("/{scheduleId}")
    public Response remove(@Context SecurityContext securityContext, @PathParam("scheduleId") final String scheduleId) {
    	ScheduleResource proxy = buildClient(securityContext);
    	return proxy.remove(scheduleId);
    }

}
