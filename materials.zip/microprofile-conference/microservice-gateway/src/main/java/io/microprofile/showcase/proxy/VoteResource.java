package io.microprofile.showcase.proxy;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.TEXT_HTML;

import java.util.Collection;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import io.microprofile.showcase.model.Attendee;
import io.microprofile.showcase.model.SessionRating;

@Path("vote")
public interface VoteResource {

	@GET
	@Path("/")
	@Produces(TEXT_HTML)
	public String info();

	@POST
	@Path("/attendee")
	@Produces(APPLICATION_JSON)
	@Consumes(APPLICATION_JSON)
	public Attendee registerAttendee(Attendee name);

	@PUT
	@Path("/attendee/{id}")
	@Produces(APPLICATION_JSON)
	@Consumes(APPLICATION_JSON)
	public Attendee updateAttendee(@PathParam("id") String id, Attendee attendee);

	@GET
	@Path("/attendee")
	@Produces(APPLICATION_JSON)
	public Collection<Attendee> getAllAttendees();

	@GET
	@Path("/attendee/{id}")
	@Produces(APPLICATION_JSON)
	public Attendee getAttendee(@PathParam("id") String id);

	@DELETE
	@Path("/attendee/{id}")
	@Produces(APPLICATION_JSON)
	public void deleteAttendee(@PathParam("id") String id);

	@POST
	@Path("/rate")
	@Produces(APPLICATION_JSON)
	@Consumes(APPLICATION_JSON)
	public SessionRating rateSession(SessionRating sessionRating);

	@GET
	@Path("/rate")
	@Produces(APPLICATION_JSON)
	public Collection<SessionRating> getAllSessionRatings();

	@PUT
	@Path("/rate/{id}")
	@Produces(APPLICATION_JSON)
	@Consumes(APPLICATION_JSON)
	public SessionRating updateRating(@PathParam("id") String id, SessionRating newRating);

	@GET
	@Path("/rate/{id}")
	@Produces(APPLICATION_JSON)
	public SessionRating getRating(@PathParam("id") String id);

	@DELETE
	@Path("/rate/{id}")
	@Produces(APPLICATION_JSON)
	public void deleteRating(@PathParam("id") String id);

	@GET
	@Path("/ratingsBySession")
	@Produces(APPLICATION_JSON)
	@Consumes(APPLICATION_JSON)
	public Collection<SessionRating> allSessionVotes(@QueryParam("sessionId") String sessionId);

	@GET
	@Path("/averageRatingBySession")
	@Produces(APPLICATION_JSON)
	@Consumes(APPLICATION_JSON)
	public double sessionRatingAverage(@QueryParam("sessionId") String sessionId);

	@GET
	@Path("/ratingsByAttendee")
	@Produces(APPLICATION_JSON)
	@Consumes(APPLICATION_JSON)
	public Collection<SessionRating> votesByAttendee(@QueryParam("attendeeId") String attendeeId);

}
