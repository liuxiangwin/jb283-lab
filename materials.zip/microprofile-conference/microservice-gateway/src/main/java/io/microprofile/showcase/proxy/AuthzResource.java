package io.microprofile.showcase.proxy;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import io.microprofile.showcase.tokens.AuthToken;
import io.microprofile.showcase.tokens.Credentials;

@Path("authz")
public interface AuthzResource {
	
	@POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public AuthToken createTokenForCredentials(Credentials credentials);

}
