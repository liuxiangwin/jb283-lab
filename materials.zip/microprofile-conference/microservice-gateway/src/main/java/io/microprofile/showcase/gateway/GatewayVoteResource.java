package io.microprofile.showcase.gateway;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.TEXT_HTML;

import java.util.Collection;

import javax.annotation.security.PermitAll;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;

import io.microprofile.showcase.model.Attendee;
import io.microprofile.showcase.model.SessionRating;
import io.microprofile.showcase.proxy.VoteResource;

@SuppressWarnings("cdi-ambiguous-dependency")
@PermitAll
@Path("gateway/vote")
@ApplicationScoped
@Consumes(MediaType.MEDIA_TYPE_WILDCARD)
public class GatewayVoteResource {

	@Inject
	@ConfigProperty(name = "voteURL", defaultValue = "http://localhost:7070")
	private String voteURL;

	private VoteResource buildClient(SecurityContext context) {
		System.out.println("Building new client");
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(voteURL);
		ResteasyWebTarget restEasyTarget = (ResteasyWebTarget) target;
		restEasyTarget.register(new GatewayJWTResponseFilter(context));
		return restEasyTarget.proxy(VoteResource.class);

	}

	@GET
	@Path("/")
	@Produces(TEXT_HTML)
	public String info(@Context SecurityContext context) {
		VoteResource proxy = buildClient(context);
		return proxy.info();
	}

	@POST
	@Path("/attendee")
	@Produces(APPLICATION_JSON)
	@Consumes(APPLICATION_JSON)
	public Attendee registerAttendee(@Context SecurityContext context, Attendee name) {
		VoteResource proxy = buildClient(context);
		return proxy.registerAttendee(name);
	}

	@PUT
	@Path("/attendee/{id}")
	@Produces(APPLICATION_JSON)
	@Consumes(APPLICATION_JSON)
	public Attendee updateAttendee(@Context SecurityContext context, @PathParam("id")String id, Attendee attendee) {
		VoteResource proxy = buildClient(context);
		return proxy.updateAttendee(id, attendee);
	}

	@GET
	@Path("/attendee")
	@Produces(APPLICATION_JSON)
	public Collection<Attendee> getAllAttendees(@Context SecurityContext context) {
		VoteResource proxy = buildClient(context);
		return proxy.getAllAttendees();
	}

	@GET
	@Path("/attendee/{id}")
	@Produces(APPLICATION_JSON)
	public Attendee getAttendee(@Context SecurityContext context, @PathParam("id")String id) {
		VoteResource proxy = buildClient(context);
		return proxy.getAttendee(id);
	}

	@DELETE
	@Path("/attendee/{id}")
	@Produces(APPLICATION_JSON)
	public void deleteAttendee(@Context SecurityContext context, @PathParam("id")String id) {
		VoteResource proxy = buildClient(context);
		proxy.deleteAttendee(id);
	}

	@POST
	@Path("/rate")
	@Produces(APPLICATION_JSON)
	@Consumes(APPLICATION_JSON)
	public SessionRating rateSession(@Context SecurityContext context, SessionRating sessionRating) {
		VoteResource proxy = buildClient(context);
		return proxy.rateSession(sessionRating);
	}

	@GET
	@Path("/rate")
	@Produces(APPLICATION_JSON)
	public Collection<SessionRating> getAllSessionRatings(@Context SecurityContext context) {
		VoteResource proxy = buildClient(context);
		return proxy.getAllSessionRatings();
	}

	@PUT
	@Path("/rate/{id}")
	@Produces(APPLICATION_JSON)
	@Consumes(APPLICATION_JSON)
	public SessionRating updateRating(@Context SecurityContext context, @PathParam("id")String id, SessionRating newRating) {
		VoteResource proxy = buildClient(context);
		return proxy.updateRating(id, newRating);
	}

	@GET
	@Path("/rate/{id}")
	@Produces(APPLICATION_JSON)
	public SessionRating getRating(@Context SecurityContext context, @PathParam("id")String id) {
		VoteResource proxy = buildClient(context);
		return proxy.getRating(id);
	}

	@DELETE
	@Path("/rate/{id}")
	@Produces(APPLICATION_JSON)
	public void deleteRating(@Context SecurityContext context, @PathParam("id")String id) {
		VoteResource proxy = buildClient(context);
		proxy.deleteRating(id);
	}

	@GET
	@Path("/ratingsBySession")
	@Produces(APPLICATION_JSON)
	@Consumes(APPLICATION_JSON)
	public Collection<SessionRating> allSessionVotes(@Context SecurityContext context, String sessionId) {
		VoteResource proxy = buildClient(context);
		return proxy.allSessionVotes(sessionId);
	}

	@GET
	@Path("/averageRatingBySession")
	@Produces(APPLICATION_JSON)
	@Consumes(APPLICATION_JSON)
	public double sessionRatingAverage(@Context SecurityContext context, String sessionId) {
		VoteResource proxy = buildClient(context);
		return proxy.sessionRatingAverage(sessionId);
	}

	@GET
	@Path("/ratingsByAttendee")
	@Produces(APPLICATION_JSON)
	@Consumes(APPLICATION_JSON)
	public Collection<SessionRating> votesByAttendee(@Context SecurityContext context, String attendeeId) {
		VoteResource proxy = buildClient(context);
		return proxy.votesByAttendee(attendeeId);
	}

}
