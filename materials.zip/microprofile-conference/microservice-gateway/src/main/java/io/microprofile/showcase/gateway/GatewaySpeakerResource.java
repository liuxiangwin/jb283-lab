package io.microprofile.showcase.gateway;

import java.util.Collection;
import java.util.Set;

import javax.annotation.security.PermitAll;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;

import io.microprofile.showcase.model.Speaker;
import io.microprofile.showcase.proxy.SpeakerResource;

@SuppressWarnings("cdi-ambiguous-dependency")
@PermitAll
@Path("gateway/speaker")
@ApplicationScoped
@Consumes(MediaType.MEDIA_TYPE_WILDCARD)
public class GatewaySpeakerResource {
	
	@Inject
	@ConfigProperty(name="speakerURL", defaultValue="http://localhost:4040")
	private String speakerURL;
	
	
	private SpeakerResource buildClient(SecurityContext context) {
		System.out.println("Building new client");
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(speakerURL);
		ResteasyWebTarget restEasyTarget = (ResteasyWebTarget)target;
		restEasyTarget.register(new GatewayJWTResponseFilter(context));
		return restEasyTarget.proxy(SpeakerResource.class);
		
	}

	@GET
	public Collection<Speaker> getAllSpeakers(@Context SecurityContext securityContext){
		SpeakerResource proxy = buildClient(securityContext);
		return proxy.getAllSpeakers();
	}
	
	@POST
    @Path("/add")
    public Speaker add(@Context SecurityContext securityContext, final Speaker speaker) {
		SpeakerResource proxy = buildClient(securityContext);
		return proxy.add(speaker);
	}

    @DELETE
    @Path("/remove/{id}")
    public void remove(@Context SecurityContext securityContext, @PathParam("id") final String id) {
    	SpeakerResource proxy = buildClient(securityContext);
    	proxy.remove(id);
    }

    @PUT
    @Path("/update")
    public Speaker update(@Context SecurityContext securityContext, final Speaker speaker) {
    	SpeakerResource proxy = buildClient(securityContext);
    	return proxy.update(speaker);
    }

    @GET
    @Path("/retrieve/{id}")
    public Speaker retrieve(@Context SecurityContext securityContext, @PathParam("id") final String id) {
    	SpeakerResource proxy = buildClient(securityContext);
    	return proxy.retrieve(id);
    }

    @PUT
    @Path("/search")
    public Set<Speaker> search(@Context SecurityContext securityContext, final Speaker speaker){
    	SpeakerResource proxy = buildClient(securityContext);
    	return proxy.search(speaker);
    }

	
}
