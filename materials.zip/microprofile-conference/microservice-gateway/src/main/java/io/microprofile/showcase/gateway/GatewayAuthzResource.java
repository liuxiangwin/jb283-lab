package io.microprofile.showcase.gateway;

import javax.annotation.security.PermitAll;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;

import io.microprofile.showcase.proxy.AuthzResource;
import io.microprofile.showcase.tokens.Credentials;

@SuppressWarnings("cdi-ambiguous-dependency")
@PermitAll
@Path("gateway/authz")
@ApplicationScoped
@Consumes(MediaType.MEDIA_TYPE_WILDCARD)
@Produces(MediaType.APPLICATION_JSON)
public class GatewayAuthzResource {
	
	@Inject
	@ConfigProperty(name="authzURL", defaultValue="http://localhost:5055")
	private String authzURL;
	
	private AuthzResource buildClient(SecurityContext context) {
		System.out.println("Building new client");
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(authzURL);
		ResteasyWebTarget restEasyTarget = (ResteasyWebTarget)target;
		restEasyTarget.register(new GatewayJWTResponseFilter(context));
		return restEasyTarget.proxy(AuthzResource.class);
		
	}
	
	@POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createTokenForCredentials(@Context SecurityContext context,Credentials credentials) throws Exception {
		AuthzResource proxy = buildClient(context);
		return Response.ok(proxy.createTokenForCredentials(credentials)).build();
	}

}
