/*
 * Copyright(c) 2017 IBM, Red Hat, and others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *      http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.microprofile.showcase.gateway;

import java.util.Collection;

import javax.annotation.security.PermitAll;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;

import io.microprofile.showcase.model.Session;
import io.microprofile.showcase.proxy.SessionResource;

@SuppressWarnings("cdi-ambiguous-dependency")
@PermitAll
@Path("gateway/sessions")
@ApplicationScoped
@Consumes(MediaType.MEDIA_TYPE_WILDCARD)
public class GatewaySessionResource {
	
	
	@Inject
	@ConfigProperty(name="sessionUrl", defaultValue="http://localhost:5050")
	private String sessionURL;
	
	
	private SessionResource buildClient(SecurityContext context) {
		System.out.println("Building new client");
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(sessionURL);
		ResteasyWebTarget restEasyTarget = (ResteasyWebTarget)target;
		restEasyTarget.register(new GatewayJWTResponseFilter(context));
		return restEasyTarget.proxy(SessionResource.class);
		
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/")
	public Collection<Session> allSessions(@Context SecurityContext securityContext,@Context HttpHeaders headers ) {
		
		SessionResource sessionProxy = buildClient(securityContext);
		return sessionProxy.allSessions();
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/")
	public Session createSession(@Context SecurityContext securityContext, Session session) {
		SessionResource sessionProxy = buildClient(securityContext);
		return sessionProxy.createSession(session);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{sessionId}")
	public Session getSession(@Context SecurityContext securityContext, @PathParam("sessionId")String sessionId) {
		SessionResource sessionProxy = buildClient(securityContext);
		return sessionProxy.getSession(sessionId);
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{sessionId}")
	public Session updateSession(@Context SecurityContext securityContext, @PathParam("sessionId")String sessionId, Session session) {
		SessionResource sessionProxy = buildClient(securityContext);
		return sessionProxy.updateSession(sessionId, session);
	}

	@DELETE
	@Path("/{sessionId}")
	public Response deleteSession(@Context SecurityContext securityContext, @PathParam("sessionId")String sessionId) {
		SessionResource sessionProxy = buildClient(securityContext);
		return sessionProxy.deleteSession(sessionId);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{sessionId}/speakers")
	public Response getSessionSpeakers(@Context SecurityContext securityContext, @PathParam("sessionId")String sessionId) {
		SessionResource sessionProxy = buildClient(securityContext);
		return sessionProxy.getSessionSpeakers(sessionId);
	}

	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{sessionId}/speakers/{speakerId}")
	public Session addSessionSpeaker(@Context SecurityContext securityContext, @PathParam("sessionId")String sessionId, @PathParam("speakerId")String speakerId) {
		SessionResource sessionProxy = buildClient(securityContext);
		return sessionProxy.addSessionSpeaker(sessionId, speakerId);
	}

	@DELETE
	@Path("/{sessionId}/speakers/{speakerId}")
	public Response removeSessionSpeaker(@Context SecurityContext securityContext, @PathParam("sessionId")String sessionId, @PathParam("speakerId")String speakerId) {
		SessionResource sessionProxy = buildClient(securityContext);
		return sessionProxy.removeSessionSpeaker(sessionId, speakerId);
	}

	

}
